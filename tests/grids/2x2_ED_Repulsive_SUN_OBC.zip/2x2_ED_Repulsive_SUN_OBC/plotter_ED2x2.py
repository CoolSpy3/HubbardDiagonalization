# -*- coding: utf-8 -*-
"""
Created on Thu Dec 12 18:11:05 2024

@author: Owner
"""

import os

import numpy as np
import matplotlib.pyplot as plt

source_path = os.getcwd()

plt.close("all")

N = 3
U = 8

mus = np.genfromtxt(os.path.join(source_path,"2x2_N%s_U%s/mu_vals.csv"%(N,U)))
Ts = np.genfromtxt(os.path.join(source_path,"2x2_N%s_U%s/T_vals.csv"%(N,U)))

rhos = np.genfromtxt(os.path.join(source_path,"2x2_N%s_U%s/Densities.csv"%(N,U)),delimiter=",")
energies = np.genfromtxt(os.path.join(source_path,"2x2_N%s_U%s/Energies.csv"%(N,U)),delimiter=",")
doublons = np.genfromtxt(os.path.join(source_path,"2x2_N%s_U%s/Doubleoccupancies.csv"%(N,U)),delimiter=",")/4
entropies = np.genfromtxt(os.path.join(source_path,"2x2_N%s_U%s/Entropies.csv"%(N,U)),delimiter=",")
cnns = np.genfromtxt(os.path.join(source_path,"2x2_N%s_U%s/CNNs.csv"%(N,U)),delimiter=",")
ninis = np.genfromtxt(os.path.join(source_path,"2x2_N%s_U%s/ninis.csv"%(N,U)),delimiter=",")

fig,axs = plt.subplots(3,2,figsize=(16,12))
colors = ["blue","gray","red"]

for Tidx in range(0,3):
    axs[0,0].plot(mus,rhos[Tidx],color=colors[Tidx],label="%1.1f"%Ts[Tidx])
    axs[0,1].plot(mus,doublons[Tidx],color=colors[Tidx])
    axs[1,0].plot(mus,energies[Tidx],color=colors[Tidx])
    axs[1,1].plot(mus,entropies[Tidx],color=colors[Tidx])
    axs[2,0].plot(mus,cnns[Tidx],color=colors[Tidx])
    axs[2,1].plot(mus,ninis[Tidx],color=colors[Tidx])
    
axs[0,0].legend(title="T/t")
axs[0,0].set_ylabel("rho")
axs[0,1].set_ylabel("D")
axs[1,0].set_ylabel("E")
axs[1,1].set_ylabel("S")
axs[2,0].set_ylabel("CNN")
axs[2,1].set_ylabel("nini/2")

axs[2,0].set_xlabel("mu/t")
axs[2,1].set_xlabel("mu/t")

plt.suptitle("2x2_N%s_U%s"%(N,U),y=0.91)

for i in range(0,3):
    for j in range(0,2):
        axs[i,j].set_xlim(-15,0)